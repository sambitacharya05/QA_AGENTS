## Application Context Broker

Use the local Application Context Broker MCP only for product-level application context needed during test case generation: reachability, navigation, pre-feature state, and entity/path variants. Do not ask it for source files, classes, methods, fixtures, page objects, raw graph neighborhoods, test design, or coverage ranking.

Prefer `resolve_application_context_for_test_cases` for feature-level gaps and `find_reachability` for direct "how do I reach this page?" gaps. Treat `unresolved_context` as unknown facts.
