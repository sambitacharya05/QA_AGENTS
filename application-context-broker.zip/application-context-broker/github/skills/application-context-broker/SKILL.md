---
name: application-context-broker
description: Supplies product-level application context from the local Application Context Broker MCP without exposing implementation details or raw graph data. Use when test case generation needs navigation, reachability, entity variants, or pre-feature state context that is missing from the requirement.
---

# Application Context Broker

## Quick Start

Use `resolve_application_context_for_test_cases` for feature-level gaps. Use `find_reachability` for direct "how does a user reach this page or area?" gaps.

Treat broker output as application context only. The test generator still owns test design, coverage choices, and final test case structure.

## When To Use

- The requirement names a page, screen, or area such as `F001` but does not explain how to reach it.
- The requirement depends on role, user type, policy status, tenant, environment, region, or similar entity context.
- The generator needs product-level setup steps before testing feature behavior.

## When Not To Use

- Do not use for test design, coverage ranking, test output formatting, or implementation details.
- Do not ask for source files, classes, methods, fixtures, page objects, framework examples, or raw graph neighborhoods.
- Do not use unresolved context as permission to invent missing product facts.

## Process

1. Use `resolve_application_context_for_test_cases` for feature-level context gaps.
2. Use `find_reachability` when the only unknown is how to reach a page or area.
3. Treat `unresolved_context` as unknown facts, not assumptions to fill.
4. Treat `path_variants` and `state_variants` as signals that separate product contexts may need separate tests.
5. Stop querying according to the test generator's own query-loop guardrail.

## References

- Tool contract: `references/broker-tool-contract.md`
- Context-card schema: `references/context-card-schema.md`
- Interpretation rules: `references/interpretation-rules.md`
- Anti-patterns: `references/anti-patterns.md`

## Examples

- Feature context query: `examples/feature-context-query.md`
- Direct reachability query: `examples/direct-reachability-query.md`
- Unresolved context: `examples/unresolved-context.md`
- Variant handling: `examples/variant-handling.md`
