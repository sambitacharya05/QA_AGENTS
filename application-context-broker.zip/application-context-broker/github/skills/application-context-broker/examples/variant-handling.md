# Variant Handling

If the broker returns separate variants for `guest` and `premium_member`, preserve both product contexts even when the visible navigation steps are similar.

The test generator decides whether those become separate test cases. The broker only supplies the context signal.
