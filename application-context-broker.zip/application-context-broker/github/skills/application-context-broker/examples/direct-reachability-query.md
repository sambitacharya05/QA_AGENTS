# Direct Reachability Query

Request:

```text
How does a user reach MyPage?
```

Use `find_reachability` with:

```json
{
  "target_page_or_area": "MyPage"
}
```
