# Feature Context Query

Request:

```text
Feature requirement: Display a notification section on top of F001. The pane displays 3 notifications by default and has a button that expands the pane.
Known gap: How does a valid user reach F001?
Target page or area: F001
```

Use `resolve_application_context_for_test_cases`.
