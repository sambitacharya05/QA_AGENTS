# Unresolved Context

If the broker returns:

```json
{
  "unresolved_context": [
    "Graph does not confirm whether environment selection is mandatory."
  ]
}
```

Do not invent an environment-selection step as a required product fact. Either omit it, mark it as unknown, or ask the owning workflow for the missing requirement depending on the generator's rules.
