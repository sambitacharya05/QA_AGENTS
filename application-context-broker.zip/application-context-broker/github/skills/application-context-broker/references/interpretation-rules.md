# Interpretation Rules

- High confidence means the graph has direct evidence for the section.
- Medium confidence means the broker inferred product context from nearby graph evidence.
- Low confidence means the broker found weak or missing evidence.
- `derivation_note` explains what kind of graph evidence supported the answer.
- `unresolved_context` must remain unknown in the generated test. Do not fill it with plausible assumptions.
- Preserve variants even when flows look identical, because the entity value may imply separate product contexts.
