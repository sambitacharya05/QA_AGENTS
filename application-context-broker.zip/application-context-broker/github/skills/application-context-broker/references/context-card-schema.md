# Context Card Schema

- `profile`: Always `application_context_for_test_cases`.
- `target_context`: Resolved page or area plus product aliases.
- `reachability`: Canonical product-level flow, confidence, and derivation note.
- `path_variants`: Graph-visible alternate paths by entity or state axis.
- `state_variants`: Required product state differences visible in the graph.
- `pre_feature_state`: Setup state needed before testing the feature behavior.
- `unresolved_context`: Facts the graph did not confirm.
- `lightweight_citations`: Product-level graph evidence summaries, never source paths or method names.
- `confidence`: Overall and section-level confidence.
