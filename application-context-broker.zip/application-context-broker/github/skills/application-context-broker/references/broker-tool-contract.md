# Broker Tool Contract

## `resolve_application_context_for_test_cases`

Use when a feature requirement is missing product-level application context.

Inputs:
- `feature_requirement`: requirement text.
- `known_gap`: explicit missing context question.
- `target_page_or_area`: named page, screen, feature id, or area.
- `budget`: optional `small`, `medium`, or `large`.

Returns one context card. It does not design tests or expose implementation evidence.

## `find_reachability`

Use when the only unknown is how a user reaches a target page, screen, or area.

Inputs:
- `target_page_or_area`: required.
- `entity_context`: optional product context such as guest, premium member, tenant, region, or policy status.

Returns reachability and variants when graph evidence supports them.

## `broker_graph_status`

Use only for installation or configuration checks. It reports graph load diagnostics.
