# Anti-Patterns

Bad requests:

- "Show me the graph neighborhood around F001."
- "Which page object method should I call?"
- "Use existing tests as examples for my output."
- "Rank all possible notification tests by coverage."
- "Give me source files and line numbers for the flow."

Good requests:

- "How does a valid user reach F001?"
- "What pre-feature state is needed before testing notification behavior on F001?"
- "Are there path variants for guest versus premium users?"
