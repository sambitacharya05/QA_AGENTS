from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", required=True)
    parser.add_argument("--graph", required=True)
    args = parser.parse_args()

    workspace = Path(args.workspace)
    mcp_path = workspace / ".vscode" / "mcp.json"
    settings_path = workspace / ".vscode" / "settings.json"

    mcp = load_json(mcp_path)
    mcp.setdefault("servers", {})
    mcp["servers"]["application-context-broker"] = {
        "type": "stdio",
        "command": "${workspaceFolder}/.context-broker/.venv/bin/python",
        "args": [
            "-m",
            "context_broker_mcp",
            "--graph",
            f"${{workspaceFolder}}/{args.graph}",
        ],
        "cwd": "${workspaceFolder}/.context-broker/broker",
    }
    write_json(mcp_path, mcp)

    settings = load_json(settings_path)
    settings["applicationContextBroker.graphPath"] = args.graph
    settings["applicationContextBroker.serverDirectory"] = ".context-broker/broker"
    write_json(settings_path, settings)


if __name__ == "__main__":
    main()
