#!/usr/bin/env bash
set -euo pipefail

DIST_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_WORKSPACE="$(pwd)"

if [[ "$TARGET_WORKSPACE" == "$DIST_DIR" ]]; then
  echo "Refusing to install into the distribution directory itself."
  exit 1
fi

PYTHON_BIN="${PYTHON_BIN:-python3}"
"$PYTHON_BIN" - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("Python 3.10+ is required.")
PY

BROKER_HOME="$TARGET_WORKSPACE/.context-broker"
VENV_DIR="$BROKER_HOME/.venv"
mkdir -p "$BROKER_HOME" "$TARGET_WORKSPACE/.vscode" "$TARGET_WORKSPACE/.github/skills"

"$PYTHON_BIN" -m venv "$VENV_DIR"
"$VENV_DIR/bin/pip" install --no-index --find-links "$DIST_DIR/wheelhouse" -r "$DIST_DIR/broker/requirements.lock"

rm -rf "$BROKER_HOME/broker"
cp -R "$DIST_DIR/broker" "$BROKER_HOME/broker"
cp -R "$DIST_DIR/github/skills/application-context-broker" "$TARGET_WORKSPACE/.github/skills/application-context-broker"

GRAPH_PATH="${APPLICATION_CONTEXT_BROKER_GRAPH:-graphify-out/graph.json}"
if [[ -f "$TARGET_WORKSPACE/JAVA_QAF/graphify-out/graph.json" && ! -f "$TARGET_WORKSPACE/$GRAPH_PATH" ]]; then
  GRAPH_PATH="JAVA_QAF/graphify-out/graph.json"
fi

"$VENV_DIR/bin/python" "$DIST_DIR/scripts/write_workspace_config.py" \
  --workspace "$TARGET_WORKSPACE" \
  --graph "$GRAPH_PATH"

MARKER_BEGIN="<!-- application-context-broker:start -->"
MARKER_END="<!-- application-context-broker:end -->"
COPILOT_FILE="$TARGET_WORKSPACE/.github/copilot-instructions.md"
touch "$COPILOT_FILE"
if ! grep -q "$MARKER_BEGIN" "$COPILOT_FILE"; then
  {
    echo ""
    echo "$MARKER_BEGIN"
    cat "$DIST_DIR/github/copilot-instructions.md"
    echo "$MARKER_END"
  } >> "$COPILOT_FILE"
fi

echo "Application Context Broker installed."
echo "Graph path: $GRAPH_PATH"
echo "MCP config: $TARGET_WORKSPACE/.vscode/mcp.json"
echo "Skill: $TARGET_WORKSPACE/.github/skills/application-context-broker"
echo "Verify with: cd \"$BROKER_HOME/broker\" && \"$VENV_DIR/bin/python\" -m context_broker_mcp --graph \"$TARGET_WORKSPACE/$GRAPH_PATH\" --once-tool broker_graph_status"
