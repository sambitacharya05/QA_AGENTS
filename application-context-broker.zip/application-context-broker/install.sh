#!/usr/bin/env bash
set -euo pipefail

DIST_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_WORKSPACE="$(pwd)"

if [[ "$TARGET_WORKSPACE" == "$DIST_DIR" ]]; then
  echo "Refusing to install into the distribution directory itself."
  exit 1
fi

if [[ -n "${PYTHON_BIN:-}" ]]; then
  PYTHON_CMD=("$PYTHON_BIN")
elif command -v python3 >/dev/null 2>&1; then
  PYTHON_CMD=(python3)
elif command -v python >/dev/null 2>&1; then
  PYTHON_CMD=(python)
elif command -v py >/dev/null 2>&1; then
  PYTHON_CMD=(py -3)
else
  echo "Python 3.10+ is required, but no python3, python, or py command was found."
  exit 1
fi

"${PYTHON_CMD[@]}" - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("Python 3.10+ is required.")
PY

case "$(uname -s 2>/dev/null || echo unknown)" in
  MINGW*|MSYS*|CYGWIN*)
    VENV_PYTHON_REL=".context-broker/.venv/Scripts/python.exe"
    VENV_PIP_REL=".context-broker/.venv/Scripts/pip.exe"
    ;;
  *)
    VENV_PYTHON_REL=".context-broker/.venv/bin/python"
    VENV_PIP_REL=".context-broker/.venv/bin/pip"
    ;;
esac

BROKER_HOME="$TARGET_WORKSPACE/.context-broker"
VENV_DIR="$BROKER_HOME/.venv"
VENV_PYTHON="$TARGET_WORKSPACE/$VENV_PYTHON_REL"
VENV_PIP="$TARGET_WORKSPACE/$VENV_PIP_REL"
mkdir -p "$BROKER_HOME" "$TARGET_WORKSPACE/.vscode" "$TARGET_WORKSPACE/.github/skills"

"${PYTHON_CMD[@]}" -m venv "$VENV_DIR"
"$VENV_PIP" install --no-index --find-links "$DIST_DIR/wheelhouse" -r "$DIST_DIR/broker/requirements.lock"

rm -rf "$BROKER_HOME/broker"
cp -R "$DIST_DIR/broker" "$BROKER_HOME/broker"
cp -R "$DIST_DIR/github/skills/application-context-broker" "$TARGET_WORKSPACE/.github/skills/application-context-broker"

DEFAULT_GRAPH_PATH="${APPLICATION_CONTEXT_BROKER_GRAPH:-}"
if [[ -z "$DEFAULT_GRAPH_PATH" ]]; then
  DEFAULT_GRAPH_PATH="graphify-out/graph.json"
  if [[ -f "$TARGET_WORKSPACE/JAVA_QAF/graphify-out/graph.json" && ! -f "$TARGET_WORKSPACE/$DEFAULT_GRAPH_PATH" ]]; then
    DEFAULT_GRAPH_PATH="JAVA_QAF/graphify-out/graph.json"
  fi
fi

if [[ -t 0 ]]; then
  echo "Enter the path to your Graphify graph.json."
  echo "Use a workspace-relative path like graphify-out/graph.json, or an absolute path."
  read -r -p "Graph path [$DEFAULT_GRAPH_PATH]: " GRAPH_PATH_INPUT
  GRAPH_PATH="${GRAPH_PATH_INPUT:-$DEFAULT_GRAPH_PATH}"
else
  GRAPH_PATH="$DEFAULT_GRAPH_PATH"
  echo "Using graph path: $GRAPH_PATH"
  echo "Set APPLICATION_CONTEXT_BROKER_GRAPH or run interactively to choose a different graph location."
fi

case "$GRAPH_PATH" in
  /*|[A-Za-z]:/*|[A-Za-z]:\\*)
    VERIFY_GRAPH_PATH="$GRAPH_PATH"
    ;;
  *)
    VERIFY_GRAPH_PATH="$TARGET_WORKSPACE/$GRAPH_PATH"
    ;;
esac

"$VENV_PYTHON" "$DIST_DIR/scripts/write_workspace_config.py" \
  --workspace "$TARGET_WORKSPACE" \
  --graph "$GRAPH_PATH" \
  --python-command "\${workspaceFolder}/$VENV_PYTHON_REL"

MARKER_BEGIN="<!-- application-context-broker:start -->"
MARKER_END="<!-- application-context-broker:end -->"
COPILOT_FILE="$TARGET_WORKSPACE/.github/copilot-instructions.md"
touch "$COPILOT_FILE"
if ! grep -q "$MARKER_BEGIN" "$COPILOT_FILE"; then
  {
    echo ""
    echo "$MARKER_BEGIN"
    cat "$DIST_DIR/github/copilot-instructions.md"
    echo "$MARKER_END"
  } >> "$COPILOT_FILE"
fi

echo "Application Context Broker installed."
echo "Graph path: $GRAPH_PATH"
echo "MCP config: $TARGET_WORKSPACE/.vscode/mcp.json"
echo "Skill: $TARGET_WORKSPACE/.github/skills/application-context-broker"
echo "Verify with: cd \"$BROKER_HOME/broker\" && \"$VENV_PYTHON\" -m context_broker_mcp --graph \"$VERIFY_GRAPH_PATH\" --once-tool broker_graph_status"
