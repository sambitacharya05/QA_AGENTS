# Application Context Broker

The Application Context Broker is a local, graph-only MCP server for test case generation agents. It reads Graphify `graph.json` and returns compact product-level context cards for reachability, navigation, entity variants, and pre-feature state.

It does not read source files, call the network, expose raw graph neighborhoods, design tests, rank coverage, or return classes, methods, fixtures, page objects, file paths, or line numbers.

## Offline Installation

Prerequisites:

- Python 3.10+
- A workspace containing a Graphify `graph.json`

From a target workspace:

```sh
/path/to/application-context-broker/install.sh
```

The installer:

- creates `.context-broker/.venv`
- installs from bundled `wheelhouse/` using `pip --no-index`
- copies the broker source into `.context-broker/broker`
- writes or merges `.vscode/mcp.json`
- writes `.vscode/settings.json`
- installs `.github/skills/application-context-broker/`
- appends a marked broker note to `.github/copilot-instructions.md`

Set a graph path with:

```sh
APPLICATION_CONTEXT_BROKER_GRAPH=graphify-out/graph.json /path/to/application-context-broker/install.sh
```

## MCP Registration

The generated `.vscode/mcp.json` registers:

```json
{
  "servers": {
    "application-context-broker": {
      "type": "stdio",
      "command": "${workspaceFolder}/.context-broker/.venv/bin/python",
      "args": ["-m", "context_broker_mcp", "--graph", "${workspaceFolder}/graphify-out/graph.json"],
      "cwd": "${workspaceFolder}/.context-broker/broker"
    }
  }
}
```

## Verify

```sh
cd .context-broker/broker
../.venv/bin/python -m context_broker_mcp --graph ../../graphify-out/graph.json --once-tool broker_graph_status
```

For the included QAF pilot graph:

```sh
PYTHONPATH=application-context-broker/broker python3 application-context-broker/broker/tests/eval_broker.py --graph JAVA_QAF/graphify-out/graph.json
```

## Troubleshooting

- Missing graph: confirm the configured `applicationContextBroker.graphPath`.
- Malformed graph: regenerate Graphify output and verify it has `nodes` and `links`.
- Python failure: confirm `python3 --version` is 3.10 or newer.
- MCP startup failure: run the verify command directly and inspect stderr.

## Security Notes

Runtime is local and read-only against the graph file. The broker makes no outbound network calls and does not inspect source, docs, tests, or test data directly.
