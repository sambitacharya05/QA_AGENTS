from __future__ import annotations

import argparse
import json
from pathlib import Path

from context_broker_mcp.server import BrokerServer


FORBIDDEN_OUTPUT_TERMS = [
    "src/test",
    "source_location",
    "HotelBookingSteps",
    "loginAs",
    "openPlansPage",
    "registerPremiumMember",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--graph", required=True)
    args = parser.parse_args()
    server = BrokerServer(args.graph)

    status = server.broker_graph_status({})
    assert status["load_status"] == "ok", status
    assert status["node_count"] > 0, status

    my_page = server.find_reachability({"target_page_or_area": "MyPage"})
    assert my_page["target_context"]["page_or_area"] == "My page", my_page
    assert my_page["reachability"]["canonical_flow"], my_page

    premium = server.resolve_application_context_for_test_cases(
        {
            "feature_requirement": "What application context is needed before testing notification behavior on MyPage/F001?",
            "target_page_or_area": "MyPage",
        }
    )
    serialized = json.dumps(premium)
    leaked = [term for term in FORBIDDEN_OUTPUT_TERMS if term in serialized]
    assert not leaked, leaked

    missing = server.find_reachability({"target_page_or_area": "DefinitelyMissingPage"})
    assert missing["confidence"]["overall"] in {"low", "medium"}, missing
    assert missing["unresolved_context"], missing

    print(json.dumps({"status": "passed", "graph": str(Path(args.graph).resolve()), "checks": 4}, indent=2))


if __name__ == "__main__":
    main()
