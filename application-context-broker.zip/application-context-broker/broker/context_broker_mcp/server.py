from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Callable

from .card_builder import build_context_card, build_reachability_card
from .graph_index import GraphIndex
from .graph_loader import GraphLoadError, load_graph


class BrokerServer:
    def __init__(self, graph_path: str):
        graph = load_graph(graph_path)
        self.index = GraphIndex(graph)
        self.tools: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {
            "resolve_application_context_for_test_cases": self.resolve_application_context_for_test_cases,
            "find_reachability": self.find_reachability,
            "broker_graph_status": self.broker_graph_status,
        }

    def list_tools(self) -> list[dict[str, Any]]:
        return [
            {
                "name": "resolve_application_context_for_test_cases",
                "description": "Returns one compact application-context card for a feature requirement or known test-generation gap. Use for product-level navigation, reachability, entity variant, and pre-feature state context. Do not use for test design, source code, framework details, raw graph exploration, or coverage ranking.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "feature_requirement": {"type": "string", "description": "Feature requirement text that lacks application context."},
                        "known_gap": {"type": "string", "description": "The specific missing app-context question, such as how a user reaches a page."},
                        "target_page_or_area": {"type": "string", "description": "Named page, screen, feature id, or area such as F001 or MyPage."},
                        "budget": {"type": "string", "description": "Optional response budget hint: small, medium, or large."},
                    },
                    "additionalProperties": False,
                },
            },
            {
                "name": "find_reachability",
                "description": "Finds product-level steps for reaching a page, screen, or application area from graph-visible navigation. Use when the only missing fact is reachability. Returns unresolved context instead of inventing paths when graph evidence is weak.",
                "inputSchema": {
                    "type": "object",
                    "required": ["target_page_or_area"],
                    "properties": {
                        "target_page_or_area": {"type": "string", "description": "Target page, screen, feature id, or area."},
                        "entity_context": {"type": "string", "description": "Optional product entity context such as guest, premium member, region, tenant, or policy status."},
                    },
                    "additionalProperties": False,
                },
            },
            {
                "name": "broker_graph_status",
                "description": "Reports whether the broker loaded the configured Graphify graph and basic diagnostics. Use for installation and configuration checks, not normal test-case generation.",
                "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
            },
        ]

    def resolve_application_context_for_test_cases(self, args: dict[str, Any]) -> dict[str, Any]:
        return build_context_card(
            self.index,
            feature_requirement=args.get("feature_requirement"),
            known_gap=args.get("known_gap"),
            target_page_or_area=args.get("target_page_or_area"),
            budget=args.get("budget"),
        )

    def find_reachability(self, args: dict[str, Any]) -> dict[str, Any]:
        target = args.get("target_page_or_area")
        if not target:
            raise ValueError("target_page_or_area is required.")
        return build_reachability_card(self.index, str(target), args.get("entity_context"))

    def broker_graph_status(self, args: dict[str, Any]) -> dict[str, Any]:
        return self.index.status()


def run_stdio(server: BrokerServer) -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
            response = handle_request(server, request)
        except Exception as exc:  # MCP callers need a structured failure, not a traceback.
            response = {"jsonrpc": "2.0", "id": None, "error": {"code": -32603, "message": str(exc)}}
        sys.stdout.write(json.dumps(response, separators=(",", ":")) + "\n")
        sys.stdout.flush()


def handle_request(server: BrokerServer, request: dict[str, Any]) -> dict[str, Any]:
    method = request.get("method")
    req_id = request.get("id")
    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "application-context-broker", "version": "0.1.0"},
            },
        }
    if method == "notifications/initialized":
        return {"jsonrpc": "2.0", "id": req_id, "result": {}}
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": req_id, "result": {"tools": server.list_tools()}}
    if method == "tools/call":
        params = request.get("params", {})
        name = params.get("name")
        args = params.get("arguments") or {}
        if name not in server.tools:
            return {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32601, "message": f"Unknown tool: {name}"}}
        result = server.tools[name](args)
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "content": [{"type": "text", "text": json.dumps(result, indent=2)}],
                "isError": False,
            },
        }
    return {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32601, "message": f"Unsupported method: {method}"}}


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Application Context Broker MCP server")
    parser.add_argument("--graph", required=True, help="Path to Graphify graph.json")
    parser.add_argument("--once-tool", help="Run one tool directly for local verification.")
    parser.add_argument("--once-args", default="{}", help="JSON arguments for --once-tool.")
    args = parser.parse_args(argv)

    try:
        server = BrokerServer(args.graph)
    except GraphLoadError as exc:
        print(f"Failed to load graph: {exc}", file=sys.stderr)
        raise SystemExit(2) from exc

    if args.once_tool:
        if args.once_tool not in server.tools:
            raise SystemExit(f"Unknown tool: {args.once_tool}")
        print(json.dumps(server.tools[args.once_tool](json.loads(args.once_args)), indent=2))
        return

    run_stdio(server)
