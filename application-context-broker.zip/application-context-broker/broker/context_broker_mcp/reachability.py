from __future__ import annotations

import re
from collections import deque
from dataclasses import dataclass

from .graph_index import GraphIndex, Transition, page_name


@dataclass(frozen=True)
class Flow:
    target_id: str
    steps: list[str]
    transitions: list[Transition]
    confidence: str
    derivation_note: str


BACKGROUND_ENTRY_TERMS = (
    "background",
    "precondition",
    "pre-condition",
    "setup",
    "set up",
    "given",
    "entrypoint",
    "entry point",
)
GENERIC_ENTRY_HINTS = (
    "home",
    "landing",
    "dashboard",
    "portal",
    "start",
    "login",
    "log in",
    "signin",
    "sign in",
    "signup",
    "sign up",
    "register",
)


def find_reachability_flow(index: GraphIndex, target_query: str, entity_context: str | None = None) -> tuple[str | None, list[Flow], list[str]]:
    anchors = index.find_anchors(target_query)
    if not anchors:
        return None, [], [f"Graph does not contain a clear page or area anchor for '{target_query}'."]

    target_ids = []
    for anchor in anchors:
        target_ids.extend(index.equivalent_ids(anchor) or [anchor])
    target_ids = list(dict.fromkeys(target_ids))
    target_id = target_ids[0]
    target_label = index.label(target_id)
    entry_ids = _entry_pages(index)
    path_items = []
    for candidate in target_ids:
        for path in _paths_to_target(index, entry_ids, candidate):
            path_items.append((candidate, path))

    if not path_items and target_id in entry_ids:
        path_items = [(target_id, [])]

    path_items = sorted(path_items, key=lambda item: (len(item[1]), _path_rank(index, item[1])))
    flows = [_path_to_flow(index, candidate, path) for candidate, path in path_items[:20]]
    flows = _prefer_entity_context(flows, entity_context)
    if flows:
        target_id = flows[0].target_id
    unresolved = []
    if not flows:
        unresolved.append(f"Graph resolves '{target_query}' to {page_name(target_label)} but does not expose a product-level path to it.")
    return target_id, flows, unresolved


def _entry_pages(index: GraphIndex) -> list[str]:
    background_entries = _background_entry_pages(index)
    pages = {transition.source_id for transition in index.transitions}
    incoming = {transition.target_id for transition in index.transitions}
    structural_entries = [page for page in pages if not _has_equivalent_incoming(index, page, incoming)]
    generic_entries = [page for page in pages if _generic_entry_score(index.label(page))]

    scored: dict[str, int] = {}
    for page in background_entries:
        scored[page] = max(scored.get(page, 0), 300)
    for page in structural_entries:
        scored[page] = max(scored.get(page, 0), 200)
    for page in generic_entries:
        scored[page] = max(scored.get(page, 0), 50)

    return sorted(scored, key=lambda node_id: (-scored[node_id], index.label(node_id)))


def _has_equivalent_incoming(index: GraphIndex, page_id: str, incoming: set[str]) -> bool:
    return any(candidate in incoming for candidate in [page_id, *index.equivalent_ids(page_id)])


def _background_entry_pages(index: GraphIndex) -> list[str]:
    entries: list[str] = []
    for node_id, node in index.nodes_by_id.items():
        if not _is_background_or_setup_node(node):
            continue
        for candidate in _nearby_page_nodes(index, node_id, max_depth=3):
            entries.extend(index.equivalent_ids(candidate) or [candidate])
    for edge in index.graph.links:
        if not _is_background_or_setup_edge(edge):
            continue
        for endpoint in (str(edge["source"]), str(edge["target"])):
            for candidate in _nearby_page_nodes(index, endpoint, max_depth=2):
                entries.extend(index.equivalent_ids(candidate) or [candidate])
    return list(dict.fromkeys(entries))


def _is_background_or_setup_node(node: dict[str, object]) -> bool:
    text = " ".join(str(node.get(key, "")) for key in ("label", "norm_label", "context", "relation")).lower()
    return any(term in text for term in BACKGROUND_ENTRY_TERMS)


def _is_background_or_setup_edge(edge: dict[str, object]) -> bool:
    text = " ".join(str(edge.get(key, "")) for key in ("label", "relation", "context")).lower()
    return any(term in text for term in BACKGROUND_ENTRY_TERMS)


def _nearby_page_nodes(index: GraphIndex, start_id: str, max_depth: int) -> list[str]:
    seen = {start_id}
    queue = deque([(start_id, 0)])
    pages: list[str] = []
    while queue:
        current, depth = queue.popleft()
        if depth > 0 and index.is_page_like(current):
            pages.append(current)
        if depth >= max_depth:
            continue
        for edge in index.out_edges.get(current, []) + index.in_edges.get(current, []):
            relation = str(edge.get("relation", ""))
            if relation in {"imports", "inherits"}:
                continue
            next_id = str(edge["target"] if edge["source"] == current else edge["source"])
            if next_id not in seen:
                seen.add(next_id)
                queue.append((next_id, depth + 1))
    return pages


def _generic_entry_score(label: str) -> int:
    norm = label.lower()
    return sum(1 for hint in GENERIC_ENTRY_HINTS if hint in norm)


def _paths_to_target(index: GraphIndex, starts: list[str], target_id: str) -> list[list[Transition]]:
    by_source: dict[str, list[Transition]] = {}
    for transition in index.transitions:
        by_source.setdefault(transition.source_id, []).append(transition)

    results: list[list[Transition]] = []
    queue = deque((start, []) for start in starts)
    while queue and len(results) < 8:
        current, path = queue.popleft()
        if current == target_id:
            results.append(path)
            continue
        if len(path) >= 5:
            continue
        visited = {step.source_id for step in path} | {step.target_id for step in path}
        for transition in _transitions_from(index, by_source, current):
            if transition.target_id in visited and transition.target_id != target_id:
                continue
            queue.append((transition.target_id, path + [transition]))
    return sorted(results, key=lambda path: (len(path), _path_rank(index, path)))


def _transitions_from(index: GraphIndex, by_source: dict[str, list[Transition]], current: str) -> list[Transition]:
    transitions: list[Transition] = []
    for source_id in [current, *index.equivalent_ids(current)]:
        transitions.extend(by_source.get(source_id, []))
    unique: dict[tuple[str, str, str], Transition] = {}
    for transition in transitions:
        unique[(transition.source_id, transition.target_id, transition.action_node_id)] = transition
    return list(unique.values())


def _path_rank(index: GraphIndex, path: list[Transition]) -> int:
    labels = " ".join(index.label(step.source_id) + " " + step.action_label for step in path).lower()
    if "login" in labels:
        return 0
    if "signup" in labels:
        return 1
    return 2


def _path_to_flow(index: GraphIndex, target_id: str, path: list[Transition]) -> Flow:
    if not path:
        steps = [f"Open {page_name(index.label(target_id))}."]
    else:
        steps = []
        first = path[0]
        steps.append(f"Open {page_name(index.label(first.source_id))}.")
        for transition in path:
            steps.append(_action_step(index, transition))
        steps.append(f"Land on {page_name(index.label(path[-1].target_id))}.")

    confidence = "high" if path else "medium"
    note = "Derived from graph-visible page return relationships and page-to-page transitions."
    return Flow(target_id=target_id, steps=_dedupe_steps(steps), transitions=path, confidence=confidence, derivation_note=note)


def _action_step(index: GraphIndex, transition: Transition) -> str:
    source = page_name(index.label(transition.source_id))
    target = page_name(index.label(transition.target_id))
    action = transition.action_label.lower()
    if "login" in action:
        return f"Sign in from {source} to reach {target}."
    if "register" in action or "signup" in action:
        return f"Complete premium signup from {source} to reach {target}."
    if "openplans" in action:
        return f"Open the plans area from {source}."
    if "reserve" in action:
        return f"Reserve the selected plan from {source} to reach {target}."
    if "complete" in action:
        return f"Complete the reservation details from {source} to reach {target}."
    return f"Continue from {source} to {target}."


def _dedupe_steps(steps: list[str]) -> list[str]:
    result: list[str] = []
    for step in steps:
        if not result or result[-1] != step:
            result.append(step)
    return result


def _prefer_entity_context(flows: list[Flow], entity_context: str | None) -> list[Flow]:
    if not entity_context:
        return flows
    wanted = re.sub(r"[^a-z0-9]+", "", entity_context.lower())
    def score(flow: Flow) -> int:
        text = " ".join(flow.steps).lower()
        if "premium" in wanted and ("premium" in text or "sign in" in text):
            return 0
        if "guest" in wanted and "plans" in text and "sign in" not in text:
            return 0
        return 1
    return sorted(flows, key=score)
