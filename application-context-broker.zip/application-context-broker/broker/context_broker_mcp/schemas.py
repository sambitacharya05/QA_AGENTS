from __future__ import annotations

from dataclasses import dataclass
from typing import Any


PROFILE = "application_context_for_test_cases"


@dataclass(frozen=True)
class BrokerLimits:
    top_anchors: int = 30
    max_expanded_nodes: int = 50
    max_depth: int = 4


def empty_context_card(query: str, target: str | None, reason: str) -> dict[str, Any]:
    return {
        "profile": PROFILE,
        "query": query,
        "target_context": {
            "page_or_area": target,
            "known_product_aliases": [],
        },
        "reachability": {
            "canonical_flow": [],
            "confidence": "low",
            "derivation_note": reason,
        },
        "path_variants": [],
        "state_variants": [],
        "pre_feature_state": [],
        "unresolved_context": [reason],
        "lightweight_citations": [],
        "confidence": {
            "overall": "low",
            "by_section": {
                "target_context": "low",
                "reachability": "low",
                "path_variants": "low",
                "state_variants": "low",
                "pre_feature_state": "low",
            },
        },
    }
