from __future__ import annotations

import re
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Any

from .graph_loader import GraphData


IMPLEMENTATION_TERMS = {
    "class",
    "method",
    "fixture",
    "page-object",
    "import",
    "inherits",
    "call-graph",
    "framework",
}


def normalize(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.lower())


def humanize_label(label: str) -> str:
    label = label.strip().strip(".")
    label = re.sub(r"\(\)$", "", label)
    label = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", label)
    label = label.replace("_", " ").replace("-", " ")
    label = re.sub(r"\s+", " ", label).strip()
    return label[:1].upper() + label[1:] if label else label


def page_name(label: str) -> str:
    text = humanize_label(label)
    return re.sub(r"\bPage\b$", "page", text).strip()


@dataclass(frozen=True)
class Transition:
    source_id: str
    target_id: str
    action_node_id: str
    action_label: str
    confidence: str


class GraphIndex:
    def __init__(self, graph: GraphData):
        self.graph = graph
        self.nodes_by_id = {str(node["id"]): node for node in graph.nodes}
        self.out_edges: dict[str, list[dict[str, Any]]] = defaultdict(list)
        self.in_edges: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for link in graph.links:
            source = str(link["source"])
            target = str(link["target"])
            self.out_edges[source].append(link)
            self.in_edges[target].append(link)

        self._norm_to_ids: dict[str, list[str]] = defaultdict(list)
        for node_id, node in self.nodes_by_id.items():
            labels = {str(node.get("label", "")), str(node.get("norm_label", "")), node_id}
            for label in labels:
                norm = normalize(label)
                if norm:
                    self._norm_to_ids[norm].append(node_id)

        self.transitions = self._build_transitions()

    def status(self) -> dict[str, Any]:
        communities = {
            node.get("community")
            for node in self.graph.nodes
            if node.get("community") is not None
        }
        return {
            "graph_path": str(self.graph.path),
            "node_count": len(self.graph.nodes),
            "edge_count": len(self.graph.links),
            "community_count": len(communities),
            "transition_count": len(self.transitions),
            "directed": bool(self.graph.raw.get("directed")),
            "load_status": "ok",
        }

    def label(self, node_id: str) -> str:
        return str(self.nodes_by_id.get(node_id, {}).get("label", node_id))

    def equivalent_ids(self, node_id: str) -> list[str]:
        norm = normalize(self.label(node_id))
        return [candidate for candidate in self._norm_to_ids.get(norm, []) if self._is_page_like(candidate)]

    def is_page_like(self, node_id: str) -> bool:
        return self._is_page_like(node_id)

    def community(self, node_id: str) -> Any:
        return self.nodes_by_id.get(node_id, {}).get("community")

    def find_anchors(self, text: str, limit: int = 30) -> list[str]:
        terms = self._candidate_terms(text)
        scored: dict[str, int] = defaultdict(int)
        for term in terms:
            norm = normalize(term)
            if not norm:
                continue
            for node_id in self._norm_to_ids.get(norm, []):
                scored[node_id] += 100
            for known_norm, ids in self._norm_to_ids.items():
                if len(norm) >= 3 and (norm in known_norm or known_norm in norm):
                    for node_id in ids:
                        scored[node_id] += 20 + min(len(norm), len(known_norm))

        page_like = [node_id for node_id in scored if self._is_page_like(node_id)]
        preferred = page_like or list(scored)
        return sorted(preferred, key=lambda node_id: (-scored[node_id], self.label(node_id)))[:limit]

    def expanded_node_ids(self, anchors: list[str], max_depth: int = 3, max_nodes: int = 50) -> list[str]:
        seen: set[str] = set()
        queue: deque[tuple[str, int]] = deque((anchor, 0) for anchor in anchors)
        while queue and len(seen) < max_nodes:
            node_id, depth = queue.popleft()
            if node_id in seen:
                continue
            seen.add(node_id)
            if depth >= max_depth:
                continue
            edges = self.out_edges.get(node_id, []) + self.in_edges.get(node_id, [])
            for edge in edges:
                relation = str(edge.get("relation", ""))
                if relation in {"imports", "inherits", "contains"}:
                    continue
                next_id = str(edge["target"] if edge["source"] == node_id else edge["source"])
                if next_id not in seen:
                    queue.append((next_id, depth + 1))
        return list(seen)

    def _candidate_terms(self, text: str) -> list[str]:
        words = re.findall(r"[A-Za-z][A-Za-z0-9_]*(?:Page)?|[A-Z]\d{3,}", text)
        phrases = re.findall(r"[A-Z][A-Za-z0-9]*(?:Page|Screen|Area)", text)
        return list(dict.fromkeys(words + phrases + [text]))

    def _is_page_like(self, node_id: str) -> bool:
        label = self.label(node_id)
        return label.endswith("Page") or "page" in label.lower()

    def _owner_page_for_method(self, method_id: str) -> str | None:
        for edge in self.in_edges.get(method_id, []):
            if edge.get("relation") == "method":
                owner = str(edge["source"])
                if self._is_page_like(owner):
                    return owner
        return None

    def _build_transitions(self) -> list[Transition]:
        transitions: list[Transition] = []
        for edge in self.graph.links:
            if edge.get("relation") != "references" or edge.get("context") != "return_type":
                continue
            action_id = str(edge["source"])
            target_id = str(edge["target"])
            source_id = self._owner_page_for_method(action_id)
            if not source_id or not self._is_page_like(target_id):
                continue
            if source_id == target_id:
                continue
            transitions.append(
                Transition(
                    source_id=source_id,
                    target_id=target_id,
                    action_node_id=action_id,
                    action_label=self.label(action_id),
                    confidence=str(edge.get("confidence", "INFERRED")).lower(),
                )
            )
        return transitions
