from __future__ import annotations


def overall_confidence(has_target: bool, flow_count: int, unresolved_count: int) -> str:
    if not has_target:
        return "low"
    if flow_count and unresolved_count == 0:
        return "high"
    if flow_count:
        return "medium"
    return "low"


def section_confidences(overall: str, has_variants: bool) -> dict[str, str]:
    return {
        "target_context": overall,
        "reachability": overall,
        "path_variants": "medium" if has_variants else "low",
        "state_variants": "medium" if has_variants else "low",
        "pre_feature_state": "medium" if overall != "low" else "low",
    }
