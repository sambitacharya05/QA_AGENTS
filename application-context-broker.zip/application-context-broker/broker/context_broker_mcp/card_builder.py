from __future__ import annotations

from typing import Any

from .confidence import overall_confidence, section_confidences
from .graph_index import GraphIndex, page_name
from .reachability import find_reachability_flow
from .schemas import PROFILE, empty_context_card
from .variants import path_variants, pre_feature_state, state_variants


def build_reachability_card(index: GraphIndex, target_page_or_area: str, entity_context: str | None = None) -> dict[str, Any]:
    target_id, flows, unresolved = find_reachability_flow(index, target_page_or_area, entity_context)
    if not target_id:
        return empty_context_card(target_page_or_area, target_page_or_area, unresolved[0])
    return _card_from_flows(index, target_page_or_area, target_id, flows, unresolved)


def build_context_card(
    index: GraphIndex,
    feature_requirement: str | None = None,
    known_gap: str | None = None,
    target_page_or_area: str | None = None,
    budget: str | None = None,
) -> dict[str, Any]:
    query = " ".join(part for part in [feature_requirement, known_gap, target_page_or_area] if part)
    target = target_page_or_area or _infer_target(index, query)
    if not target:
        return empty_context_card(query, target, "No target page or application area could be resolved from the request.")
    target_id, flows, unresolved = find_reachability_flow(index, target, query)
    if not target_id:
        return empty_context_card(query, target, unresolved[0])
    return _card_from_flows(index, query, target_id, flows, unresolved)


def _infer_target(index: GraphIndex, query: str) -> str | None:
    anchors = index.find_anchors(query, limit=1)
    return index.label(anchors[0]) if anchors else None


def _card_from_flows(index: GraphIndex, query: str, target_id: str, flows: list[Any], unresolved: list[str]) -> dict[str, Any]:
    target_label = index.label(target_id)
    aliases = sorted({page_name(index.label(anchor)) for anchor in index.equivalent_ids(target_id)})
    canonical = flows[0] if flows else None
    variants = path_variants(index, flows)
    states = state_variants(index, flows)
    overall = overall_confidence(True, len(flows), len(unresolved))
    citations = _citations(index, flows[:3])

    return {
        "profile": PROFILE,
        "query": query,
        "target_context": {
            "page_or_area": page_name(target_label),
            "known_product_aliases": aliases,
        },
        "reachability": {
            "canonical_flow": canonical.steps if canonical else [],
            "confidence": canonical.confidence if canonical else "low",
            "derivation_note": canonical.derivation_note if canonical else "No graph-visible path was found.",
        },
        "path_variants": variants,
        "state_variants": states,
        "pre_feature_state": pre_feature_state(flows),
        "unresolved_context": unresolved,
        "lightweight_citations": citations,
        "confidence": {
            "overall": overall,
            "by_section": section_confidences(overall, bool(variants or states)),
        },
    }


def _citations(index: GraphIndex, flows: list[Any]) -> list[dict[str, str]]:
    citations: list[dict[str, str]] = []
    seen: set[str] = set()
    counter = 1
    for flow in flows:
        for transition in flow.transitions:
            key = f"{transition.source_id}->{transition.target_id}"
            if key in seen:
                continue
            citations.append(
                {
                    "id": f"graph-evidence-{counter}",
                    "supports": f"Reachability from {page_name(index.label(transition.source_id))} to {page_name(index.label(transition.target_id))}",
                    "evidence_summary": "Graph contains a page transition represented by a return relationship. Source paths and implementation symbols are intentionally omitted.",
                    "source_type": "reference_graph",
                }
            )
            seen.add(key)
            counter += 1
    return citations[:10]
