from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class GraphLoadError(ValueError):
    pass


@dataclass(frozen=True)
class GraphData:
    path: Path
    raw: dict[str, Any]
    nodes: list[dict[str, Any]]
    links: list[dict[str, Any]]


def load_graph(path: str | Path) -> GraphData:
    graph_path = Path(path).expanduser().resolve()
    if not graph_path.exists():
        raise GraphLoadError(f"Graph file does not exist: {graph_path}")
    if not graph_path.is_file():
        raise GraphLoadError(f"Graph path is not a file: {graph_path}")

    try:
        raw = json.loads(graph_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise GraphLoadError(f"Malformed graph JSON at {graph_path}: {exc}") from exc

    if not isinstance(raw, dict):
        raise GraphLoadError("Graph JSON must be an object.")
    nodes = raw.get("nodes")
    links = raw.get("links", raw.get("edges"))
    if not isinstance(nodes, list) or not isinstance(links, list):
        raise GraphLoadError("Graph JSON must contain list fields 'nodes' and 'links' or 'edges'.")

    missing_node_ids = [i for i, node in enumerate(nodes) if not isinstance(node, dict) or "id" not in node]
    if missing_node_ids:
        raise GraphLoadError(f"Graph has nodes without ids at indexes: {missing_node_ids[:5]}")

    bad_links = [
        i
        for i, link in enumerate(links)
        if not isinstance(link, dict) or "source" not in link or "target" not in link
    ]
    if bad_links:
        raise GraphLoadError(f"Graph has links without source/target at indexes: {bad_links[:5]}")

    return GraphData(path=graph_path, raw=raw, nodes=nodes, links=links)
