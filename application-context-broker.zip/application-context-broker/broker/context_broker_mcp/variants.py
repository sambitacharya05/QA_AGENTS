from __future__ import annotations

from .graph_index import GraphIndex
from .reachability import Flow


def path_variants(index: GraphIndex, flows: list[Flow]) -> list[dict[str, object]]:
    variants: list[dict[str, object]] = []
    for flow in flows:
        text = " ".join(flow.steps).lower()
        if "premium" in text or "sign in" in text:
            variants.append(
                {
                    "variant_axis": "membership_state",
                    "variant_value": "premium_member",
                    "flow": flow.steps,
                    "confidence": "medium",
                }
            )
        elif "plans" in text:
            variants.append(
                {
                    "variant_axis": "membership_state",
                    "variant_value": "guest_or_public_visitor",
                    "flow": flow.steps,
                    "confidence": "medium",
                }
            )
    return _unique_variants(variants)


def state_variants(index: GraphIndex, flows: list[Flow]) -> list[dict[str, object]]:
    variants: list[dict[str, object]] = []
    labels = " ".join(node.get("label", "") for node in index.graph.nodes).lower()
    if flows and "premium" in labels:
        variants.append(
            {
                "variant_axis": "membership_state",
                "variant_value": "premium_member",
                "required_state": ["Premium membership or premium credentials are available before premium-only flows."],
                "confidence": "medium",
            }
        )
    if flows and "reservation" in labels:
        variants.append(
            {
                "variant_axis": "reservation_state",
                "variant_value": "configured_reservation",
                "required_state": ["A selected plan and reservation details are available before reservation completion."],
                "confidence": "medium",
            }
        )
    return variants


def pre_feature_state(flows: list[Flow]) -> list[str]:
    if not flows:
        return []
    text = " ".join(step for flow in flows[:2] for step in flow.steps).lower()
    state: list[str] = []
    if "sign in" in text:
        state.append("A valid user can authenticate before reaching the target area.")
    if "premium" in text:
        state.append("Premium-member context may be required for premium-only paths.")
    if "reservation" in text:
        state.append("A selected plan exists before reservation details are completed.")
    return state


def _unique_variants(variants: list[dict[str, object]]) -> list[dict[str, object]]:
    seen: set[tuple[object, object]] = set()
    result: list[dict[str, object]] = []
    for variant in variants:
        key = (variant["variant_axis"], variant["variant_value"])
        if key not in seen:
            result.append(variant)
            seen.add(key)
    return result
