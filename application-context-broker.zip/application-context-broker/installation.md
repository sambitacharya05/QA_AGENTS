**Package It**
From the repo root:

```sh
cd /Users/sambitacharya/Documents/projects/AGENTS_MASTER/context_extractor
zip -r application-context-broker.zip application-context-broker \
  -x "*/__pycache__/*" \
  -x "*.pyc"
```

That produces:

```text
application-context-broker.zip
```

The `wheelhouse/` can stay empty for now because `requirements.lock` has no package dependencies.

**Install It Locally**
If you want to install into this current workspace, run from the workspace root, not from inside `application-context-broker/`:

```sh
cd /Users/sambitacharya/Documents/projects/AGENTS_MASTER/context_extractor
./application-context-broker/install.sh
```

The installer should auto-detect:

```text
JAVA_QAF/graphify-out/graph.json
```

because that graph exists in this workspace.

The installer prompts for the graph location. Press Enter to accept the detected
default, or enter a workspace-relative path such as `graphify-out/graph.json` or
an absolute path.

**Install From The Zip Elsewhere**
On another machine/workspace:

```sh
unzip application-context-broker.zip
cd /path/to/target/workspace
/path/to/unzipped/application-context-broker/install.sh
```

For non-interactive installs, or if you want to preselect the graph path:

```sh
APPLICATION_CONTEXT_BROKER_GRAPH=graphify-out/graph.json /path/to/application-context-broker/install.sh
```

**Verify Install**
After install, run the command printed by the installer, or generally:

```sh
cd .context-broker/broker
../.venv/bin/python -m context_broker_mcp \
  --graph ../../JAVA_QAF/graphify-out/graph.json \
  --once-tool broker_graph_status
```

For a standard target workspace where the graph is directly at `graphify-out/graph.json`, use:

```sh
cd .context-broker/broker
../.venv/bin/python -m context_broker_mcp \
  --graph ../../graphify-out/graph.json \
  --once-tool broker_graph_status
```

You should see `load_status: ok`, plus node/edge counts.

**What Gets Installed**
The installer writes:

```text
.context-broker/
.vscode/mcp.json
.vscode/settings.json
.github/skills/application-context-broker/
.github/copilot-instructions.md
```

Then your MCP-capable agent/editor should see the `application-context-broker` server with the three tools.
