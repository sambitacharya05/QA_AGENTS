# User Guide

Use the broker when a test case generator needs application context that the requirement does not provide.

Good uses:

- "How does a valid user reach F001?"
- "What app context is needed before testing notification behavior on MyPage?"
- "Are guest and premium paths different for reservation?"

Do not use it for:

- test design or output formatting
- coverage ranking
- source files, classes, methods, fixtures, page objects, or framework examples
- raw graph exploration

## Tools

Use `resolve_application_context_for_test_cases` for feature-level gaps. Use `find_reachability` for direct reachability questions.

## Reading The Card

- `reachability`: canonical product-level flow.
- `path_variants`: alternate graph-visible navigation paths.
- `state_variants`: product states that may split test contexts.
- `pre_feature_state`: setup state before feature behavior starts.
- `unresolved_context`: unknown facts. Do not invent them.
- `confidence`: how strongly the graph supports each section.
- `derivation_note`: why the broker believes the context is supported.

Identical flows under different entity values should still be preserved as separate product contexts. The generator decides final test shape.

## FAQ

Does the broker need the internet? No.

Does it read source files? No. It reads only Graphify `graph.json`.

What if context is missing? Use `unresolved_context` as an explicit unknown.

Can I change the graph path? Yes, edit `.vscode/settings.json` and `.vscode/mcp.json`, or reinstall with `APPLICATION_CONTEXT_BROKER_GRAPH`.
